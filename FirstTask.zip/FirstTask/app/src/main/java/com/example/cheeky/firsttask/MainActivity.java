package com.example.cheeky.firsttask;

import android.app.Activity;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends Activity implements  MyRecyclerViewAdapter.ItemClickListener {
    private String TAG = "MainActivity";
    private String data = "";
    private ArrayList<User> Users = new ArrayList<>();
    private RecyclerView myRecyclerView;
    private MyRecyclerViewAdapter mAdapter;
    private GestureDetector gestureDetector;
    private String answer = "";
    private int position = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myRecyclerView = findViewById(R.id.RecycleView);

        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(MainActivity.this,
                LinearLayoutManager.VERTICAL, false);
        myRecyclerView.setLayoutManager(mLinearLayoutManager);
        myRecyclerView.addItemDecoration(new DividerItemDecoration(MainActivity.this,
                DividerItemDecoration.VERTICAL));

        //Users.add(new User(0,"Jon99", "admin", "men", "jon99@gmail.com", "http://aedaw/wdawdf.jpg"));
        //Users.add(new User(0,"Jon99", "admin", "men", "jon99@gmail.com", "http://aedaw/wdawdf.jpg"));

        try {
            answer = new MyTask().execute(Integer.toString(position)).get();
            addUsers(answer);
            position = Users.get(8).getId();
        } catch (Exception e){
            //errors += "Errors: " + e.toString();
            Toast.makeText(this, "Error: " + e.toString(), Toast.LENGTH_LONG);
        }


        mAdapter = new MyRecyclerViewAdapter(MainActivity.this, Users);
        myRecyclerView.setAdapter(mAdapter);
        mAdapter.setClickListener(this);

        gestureDetector = initGestureDetector();

        View view = findViewById(R.id.RecycleView);

        view.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                return gestureDetector.onTouchEvent(event);
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
            }
        });
    }

    @Override
    public void onItemClick(View view, int position) {
        Toast.makeText(this, "You clicked on position: " + mAdapter.getItem(position), Toast.LENGTH_LONG).show();
    }

    private GestureDetector initGestureDetector() {
        return new GestureDetector(new GestureDetector.SimpleOnGestureListener(){

            private SwipeDetector detector = new SwipeDetector();

            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX,
                                   float velocityY) {
                try {
                    if (detector.isSwipeDown(e1, e2, velocityY)) {
                        return false;
                    } else if (detector.isSwipeUp(e1, e2, velocityY)) {
                        answer = new MyTask().execute(Integer.toString(position)).get();
                        //Users.clear();
                        addUsers(answer);
                        mAdapter.addUssers(Users);
                        position = Users.get(Users.size()).getId();
                        showToast("Up Swipe");
                    }else if (detector.isSwipeLeft(e1, e2, velocityX)) {
                        showToast("Left Swipe");
                    } else if (detector.isSwipeRight(e1, e2, velocityX)) {
                        showToast("Right Swipe");
                    }
                } catch (Exception e) {} //for now, ignore
                return false;
            }

            private void showToast(String phrase){
                Toast.makeText(getApplicationContext(), phrase, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void addUsers(String jsonArrayAnswer){
        if (jsonArrayAnswer != null && !jsonArrayAnswer.trim().equals("")) {
            try {
                JSONArray ja = new JSONArray(jsonArrayAnswer);
                JSONObject jo;
                int i = 0;

                while (i < ja.length()) {
                    // разберем JSON массив построчно
                    jo = ja.getJSONObject(i);
                    Users.add(new User(jo.getInt("id"), jo.getString("login"), jo.getString("password"), jo.getString("sex"), jo.getString("email"),jo.getString("img_link")));
                    i++;
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error: " + e.toString(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }
    }
}
