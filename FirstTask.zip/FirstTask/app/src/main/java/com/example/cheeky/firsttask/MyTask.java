package com.example.cheeky.firsttask;

import android.content.ContentValues;
import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MyTask extends AsyncTask<String, Void, String> {
    String all_data = "";
    private HttpURLConnection connection1;

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... params) {
        String answer = "";
        //String _text = "";
        String lnk = "http://medecinehelper.000webhostapp.com/get9_users.php?position="+params[0];
        //ContentValues new_mess;
        try {
            connection1 = (HttpURLConnection) new URL(lnk).openConnection();
            connection1.setReadTimeout(10000);
            connection1.setConnectTimeout(15000);
            connection1.setRequestMethod("GET");
            connection1.setRequestProperty("User-Agent", "Mozilla/5.0");
            connection1.setDoInput(true);
            connection1.connect();
        } catch (Exception e) {
            all_data += "error: " +  e.toString();
        }
        // получаем ответ --------------------------------------------------------->
        try {
            InputStream is1 = connection1.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(is1, "UTF-8"));
            StringBuilder sb1 = new StringBuilder();
            String bfr_st1;

            while ((bfr_st1 = br1.readLine()) != null) {
                sb1.append(bfr_st1);
            }
            answer = sb1.toString();
            answer = answer.substring(0, answer.indexOf("]") + 1);
            is1.close(); // закроем поток
            br1.close(); // закроем буфер

        } catch (Exception e) {
            all_data += "\nError: " + e.toString();
        } finally {
            connection1.disconnect();
        }
        return answer;
    }
    @Override
    protected void onPostExecute(String result) {
        super.onPostExecute(result);
    }
}
