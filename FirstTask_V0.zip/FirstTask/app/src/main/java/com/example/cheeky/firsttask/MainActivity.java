package com.example.cheeky.firsttask;

import android.app.Activity;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends Activity implements  MyRecyclerViewAdapter.ItemClickListener {
    private String TAG = "MainActivity";
    private String data = "";
    private ArrayList<User> Users = new ArrayList<>();
    private RecyclerView myRecyclerView;
    private MyRecyclerViewAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myRecyclerView = findViewById(R.id.RecycleView);

        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(MainActivity.this,
                LinearLayoutManager.VERTICAL, false);
        myRecyclerView.setLayoutManager(mLinearLayoutManager);
        myRecyclerView.addItemDecoration(new DividerItemDecoration(MainActivity.this,
                DividerItemDecoration.VERTICAL));

        //Users.add(new User(0,"Jon99", "admin", "men", "jon99@gmail.com", "http://aedaw/wdawdf.jpg"));
        String errors = "";
        try {
            errors = new myTask().execute().get();
        } catch (Exception e){
            errors += "Errors: " + e.toString();
            Toast.makeText(this, "Error: " + e.toString(), Toast.LENGTH_LONG);
        }


        mAdapter = new MyRecyclerViewAdapter(MainActivity.this, Users);
        myRecyclerView.setAdapter(mAdapter);
        mAdapter.setClickListener(this);
    }

    @Override
    public void onItemClick(View view, int position) {
        Toast.makeText(this, "You clicked on position: " + mAdapter.getItem(position), Toast.LENGTH_LONG).show();
    }

    public class myTask extends AsyncTask<String, Void, String> {
        String all_data = "";
        private HttpURLConnection connection1;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(final String... params) {
            String answer = "";
            String _text = "";
            String lnk = "http://medecinehelper.000webhostapp.com/get9_users.php";
            ContentValues new_mess;
            try {
                connection1 = (HttpURLConnection) new URL(lnk).openConnection();
                connection1.setReadTimeout(10000);
                connection1.setConnectTimeout(15000);
                connection1.setRequestMethod("GET");
                connection1.setRequestProperty("User-Agent", "Mozilla/5.0");
                connection1.setDoInput(true);
                connection1.connect();
            } catch (Exception e) {
                all_data += "error: " +  e.toString();
            }
            // получаем ответ --------------------------------------------------------->
            try {
                InputStream is1 = connection1.getInputStream();
                BufferedReader br1 = new BufferedReader(new InputStreamReader(is1, "UTF-8"));
                StringBuilder sb1 = new StringBuilder();
                String bfr_st1;

                while ((bfr_st1 = br1.readLine()) != null) {
                    sb1.append(bfr_st1);
                }
                answer = sb1.toString();
                answer = answer.substring(0, answer.indexOf("]") + 1);
                is1.close(); // закроем поток
                br1.close(); // закроем буфер
                //connection1.disconnect();

            } catch (Exception e) {
                all_data += "\nError: " + e.toString();
            } finally {
                connection1.disconnect();
            }

            // запишем ответ в БД ----------------------------------------------------->
            if (answer != null && !answer.trim().equals("")) {
                try {
                    JSONArray ja = new JSONArray(answer);
                    JSONObject jo;
                    int i = 0;

                    while (i < ja.length()) {
                        // разберем JSON массив построчно
                        jo = ja.getJSONObject(i);
                        Users.add(new User(jo.getInt("id"), jo.getString("login"), jo.getString("password"), jo.getString("sex"), jo.getString("email"),jo.getString("img_link")));
                        i++;
                    }
                } catch (Exception e) {
                    all_data += "\nError: " + e.toString();
                }
            } else {
                all_data += "\nError";
            }
            return all_data;
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
        }
    }
}
