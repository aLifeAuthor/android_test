package com.example.cheeky.firsttask;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.media.Image;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class User {
    private int id;
    private String login;
    private String password;
    private String sex;
    private String email;
    private String imgLink;
    private SQLiteDatabase DBlocal;

    public User(int id, String log, String pass, String s, String e, String img){
        this.id = id;
        this.login = log;
        this.password = pass;
        this.sex = s;
        this.email = e;
        this.imgLink = img;
    }

    public String getLogin(){
        return login;
    }
    public String getSex(){
        return sex;
    }
    public int getId(){
        return id;
    }
    public String getEmail() {
        return email;
    }

    public String Info() {
        return "id: " + id + "; login: " + login + "; password: " + password + "; sex: " + sex + "; email: " + email
                + "; imgLink: " + imgLink;
    }
}
